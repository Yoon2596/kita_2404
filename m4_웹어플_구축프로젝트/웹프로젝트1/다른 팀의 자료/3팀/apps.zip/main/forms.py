from flask_wtf import FlaskForm


class ModelCapacityForm(FlaskForm):
    pass


class EmptyForm(FlaskForm):
    pass
